import React from 'react'
import LandingHero from '../../components/LandingHero/LandingHero'

function HeroSection() {
  return (
    <LandingHero/>
  )
}

export default HeroSection